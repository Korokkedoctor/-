#include "Shift.h"


void Shift::encryption(std::ifstream& fin, std::ofstream& fout, int n) {
    char ch;
	while(fin.get(ch))
	{ 
        //ch = (ch + n) % 26; // ƫ�� n ���ַ�
        //fout << ch;
        fout<<char((int(ch)+n)%128);
	}

}

void Shift::decryption(std::ifstream& fin, std::ofstream& fout, int n) {
    char ch;
    while(fin.get(ch)) 	
	{
		//ch = (ch - n) % 26; // ƫ�� n ���ַ�
        //fout << ch;
        fout<<char((int(ch)-n)%128);
	}
}


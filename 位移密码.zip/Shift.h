#ifndef SHIFT_H
#define SHIFT_H

#include <iostream>
#include <fstream>

class Shift {
public: 
    void encryption(std::ifstream& fin, std::ofstream& fout, int n);
    void decryption(std::ifstream& fin, std::ofstream& fout, int n);
};


#endif

